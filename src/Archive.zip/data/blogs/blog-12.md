---
title: 'the choice is easy blinded to the needs of hardship'
date: "2020-02-21 10:00:00"
author: 'Fatima Lima'
format: 'image'
image: '../images/blog-8.jpg'
category: technology
tags: ['react', 'markdown', 'gatsby blog']
keywords: ['react', 'markdown', 'gatsby blog']
---

Diseases like these are not the only threat to bee populations. The use of pesticides and herbicides, as well as the growing urban sprawl, all have detrimental effects. Although, the extinction of bees would not lead to famine—since most cereal crops are wind-pollinated, the majority of fruits and vegetables are insect-pollinated and without bees these would have to be pollinated manually, or by robots—which is unlikely to happen in Sri Lanka anytime soon. Crops that are not cost-effective to hand or robot-pollinate, would likely be lost

There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum. You need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend toitrrepeat predefined chunks.

There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum. You need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend toitrrepeat predefined chunks.

Necessary, making this the first true generator on the Internet. It re are many variations of passages of Lo rem Ipsum available, but the majority have suffered alteration in some form, by injectedeed eedhumour, or randomised words which don't look even slightly believable.

<div class="row mb-30">
    <div class="col-md-6">
        <figure>
            <img src="../images/image-2.jpg" alt="single blog"/>
        </figure>
    </div>
    <div class="col-md-6">
        <figure>
            <img src="../images/image-3.jpg" alt="single blog"/>
        </figure>
    </div>
</div>

There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum. You need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend toitrrepeat predefined chunks.

>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes.

There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum. You need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend toitrrepeat predefined chunks. Necessary, making this the first true generator on the Internet. It re are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injectedeed eedhumour, or randomised words which don't look even slightly believable.

<div class="row mb-30">
    <div class="col-md-6">
        <figure>
            <img src="../images/image-1.jpg" alt="single blog"/>
             <figcaption>Internet tend toitrrepeat predefined chunks.</figcaption>
        </figure>
    </div>
    <div class="col-md-6">
        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.</p>
        <h5 class="mb-15">Ordered & Unordered Lists.</h5>
        <ul class="mb-30">
            <li>Yet this above sewed flirted opened ouch</li>
            <li>Goldfinch realistic sporadic ingenuous</li>
            <li>Abominable this abidin far successfully </li>
        </ul>
        <h5 class="mb-15">Ordered & Unordered Lists.</h5>
        <ul>
            <li>Yet this above sewed flirted opened ouch</li>
            <li>Goldfinch realistic sporadic ingenuous</li>
            <li>Abominable this abidin far successfully </li>
        </ul>
    </div>
</div>

There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum. You need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend toitrrepeat predefined chunks. Necessary, making this the first true generator on the Internet. It re are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injectedeed eedhumour, or randomised words which don't look even slightly believable.