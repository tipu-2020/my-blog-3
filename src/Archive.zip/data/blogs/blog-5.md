---
title: "the great times that we can choose the other choices"
date: "2020-02-21 05:30:00"
author: "Fatima Lima"
format: "image"
image: "../images/blog-5.jpg"
category: technology
tags: ['react', 'markdown', 'gatsby blog']
description: "One of the members of the Bee Protection Organisation in Meerigama had around 300 beeboxes, and another member in Attanagalla has about 100"
keywords: ['react', 'markdown', 'gatsby blog']
---

Also contributing, is the fact that only the mee massa, of just four honey bee species in Sri Lanka can be domesticated, because only it builds its hive in enclosed spaces making it suitable for beekeeping. Small, red bees, the bambara and the danduwel massa, build their hives in open spaces, such as on trees or high up on buildings, while the fourth species, the kano mee, a small stingless species, only produces small quantities of honey.

There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum. You need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend toitrrepeat predefined chunks.

There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum. You need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend toitrrepeat predefined chunks.

Necessary, making this the first true generator on the Internet. It re are many variations of passages of Lo rem Ipsum available, but the majority have suffered alteration in some form, by injectedeed eedhumour, or randomised words which don't look even slightly believable.

<div class="row mb-30">
    <div class="col-md-6">
        <figure>
            <img src="../images/image-2.jpg" alt="single blog"/>
        </figure>
    </div>
    <div class="col-md-6">
        <figure>
            <img src="../images/image-3.jpg" alt="single blog"/>
        </figure>
    </div>
</div>

There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum. You need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend toitrrepeat predefined chunks.

> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes.

There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum. You need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend toitrrepeat predefined chunks. Necessary, making this the first true generator on the Internet. It re are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injectedeed eedhumour, or randomised words which don't look even slightly believable.

<div class="row mb-30">
    <div class="col-md-6">
        <figure>
            <img src="../images/image-1.jpg" alt="single blog"/>
             <figcaption>Internet tend toitrrepeat predefined chunks.</figcaption>
        </figure>
    </div>
    <div class="col-md-6">
        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.</p>
        <h5 class="mb-15">Ordered & Unordered Lists.</h5>
        <ul class="mb-30">
            <li>Yet this above sewed flirted opened ouch</li>
            <li>Goldfinch realistic sporadic ingenuous</li>
            <li>Abominable this abidin far successfully </li>
        </ul>
        <h5 class="mb-15">Ordered & Unordered Lists.</h5>
        <ul>
            <li>Yet this above sewed flirted opened ouch</li>
            <li>Goldfinch realistic sporadic ingenuous</li>
            <li>Abominable this abidin far successfully </li>
        </ul>
    </div>
</div>

There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum. You need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend toitrrepeat predefined chunks. Necessary, making this the first true generator on the Internet. It re are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injectedeed eedhumour, or randomised words which don't look even slightly believable.
