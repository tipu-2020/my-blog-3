import styled from "styled-components";

export const ContactBannerWrap = styled.div `
    margin-bottom: 37px;
    img{
        border-radius: 5px;
    }
`;