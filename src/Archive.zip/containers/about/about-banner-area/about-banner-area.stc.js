import styled from "styled-components";

export const AboutBannerWrap = styled.div `
    margin-bottom: 50px;
    img{
        border-radius: 5px;
    }
`;