import styled from "styled-components";

export const BlogThumb = styled.figure `
    img{
        border-radius: 5px;
    }
`;
