import styled from 'styled-components'

export const FormWrapper = styled.div ``;
export const BtnWrap = styled.div `
    position: absolute;
    right: 25px;
    top: 50%;
    transform: translateY(-50%);
`;