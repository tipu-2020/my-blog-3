import styled from 'styled-components'

export const FormWrapper = styled.div ``;

export const SubscribeText = styled.p `
    color: #fff;
    font-size: 14px;
    margin-bottom: 26px;
    margin-top: -10px;
`;