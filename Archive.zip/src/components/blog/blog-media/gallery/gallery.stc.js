import styled from "styled-components";

export const GalleryWrap = styled.div`
	position: relative;
    img{
        border-radius: 5px;
    }
`;