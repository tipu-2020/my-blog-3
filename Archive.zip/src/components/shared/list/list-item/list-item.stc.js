import styled from "styled-components";

export const ListItemWrap = styled.li ``;