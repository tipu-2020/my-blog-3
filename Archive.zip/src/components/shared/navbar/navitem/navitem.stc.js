import styled from 'styled-components';

export const NavItemWrap = styled.li `
    padding: 0 18px;  
`;
 